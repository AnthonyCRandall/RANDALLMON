/*
Dead Among us object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class Amongusdead {
    
    private int x=0;
    private int y=0;
    
    static Color SussyYellow = new Color(232, 252, 3);

public Amongusdead (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
//among us died
    
    //Outline
    g.setColor(Color.BLACK);
    g.drawRect(x+50, y+410, 120, 90);
    g.drawRect(x+225, y+410, 1, 100);
    g.drawRect(x+170, y+410, 10, 1);
    g.drawRect(x+181, y+411, 1, 7);
    g.drawRect(x+183, y+418, 1, 5);
    g.drawRect(x+185, y+423, 5, 1);
    g.drawRect(x+191, y+418, 1, 5);
    g.drawRect(x+192, y+416, 7, 1);
    g.drawRect(x+200, y+417, 1, 3);
    g.drawRect(x+201, y+421, 3, 1);
    g.drawRect(x+205, y+416, 1, 5);
    g.drawRect(x+207, y+415, 7, 1);
    g.drawRect(x+215, y+411, 1, 4);
    g.drawRect(x+217, y+410, 7, 1);
    
    //outline bone
    g.drawRect(x+193, y+395, 1, 20);
    g.drawRect(x+205, y+395, 1, 20);
    g.drawArc(x+180, y+369, 23, 25, 270, -223);
    g.drawArc(x+195, y+369, 23, 25, 128, -223);
    
    //fill bone
    g.setColor(Color.WHITE);
    g.fillArc(x+180, y+370, 23, 23, 270, -360);
    g.fillArc(x+195, y+370, 23, 23, 128, -360);
    g.fillRect(x+194, y+390, 12, 25);
    g.fillRect(x+201, y+411, 4, 10);
    
    //Fill yellow
    g.setColor(SussyYellow);
    g.fillRect(x+51, y+411, 119, 89);
    g.fillRect(x+171, y+412, 9, 90);
    g.fillRect(x+171, y+419, 12, 90);
    g.fillRect(x+171, y+424, 54, 90);
    g.fillRect(x+193, y+418, 7, 90);
    g.fillRect(x+200, y+423, 25, 90);
    g.fillRect(x+207, y+417, 18, 90);
    g.fillRect(x+217, y+412, 8, 90);
    
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method
    
}
