/*
Hunter Object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class User {// Starts Class
    
    private int x=0;
    private int y=0;
    
    static Color UserBrown = new Color(163, 100, 36);

public User (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
    //Skin
    g.setColor(UserBrown);
    g.fillRect(x+250, y+250, 12, 24);
    
    //Eyes
    g.setColor(Color.BLACK);
    g.fillRect(x+253, y+254, 3, 3);
    g.fillRect(x+259, y+254, 3, 3);
    
    //Headband
    g.setColor(Color.WHITE);
    g.fillRect(x+253, y+250, 9, 3);
    
    
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method
    
}// Ends Class
