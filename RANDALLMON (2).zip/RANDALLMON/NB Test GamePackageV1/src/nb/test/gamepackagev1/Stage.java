/*
Stage Object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class Stage {
    
    private int x=0;
    private int y=0;
    
    static Color StageTan = new Color(230, 181, 57);

public Stage (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
    //Stage
    g.setColor(Color.BLACK);  
    g.drawOval(x-50, y+380, 400, 250);
    g.drawOval(x+250, y+200, 225, 100);
    
    g.setColor(StageTan);   
    g.fillOval(x-50, y+381, 399, 249);
    g.fillOval(x+251, y+201, 223, 98);
   
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method
    
}
