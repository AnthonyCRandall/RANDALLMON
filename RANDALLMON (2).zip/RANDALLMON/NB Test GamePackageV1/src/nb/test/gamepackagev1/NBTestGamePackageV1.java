
package nb.test.gamepackagev1;
import edu.sjcny.gpv1.*;
import java.awt.*;
import javax.swing.*;
import java.util.Random;

public class NBTestGamePackageV1 extends DrawableAdapter
{  // start class 
    static NBTestGamePackageV1 ge = new NBTestGamePackageV1(); 
    static GameBoard gb = new GameBoard(ge, "Blank Game Board");
    static User Main = new User(0,0);
    static Rock rock1 = new Rock(0,0);
    static Amongus Buddy = new Amongus(0,0);
    static Stage BattleStage = new Stage(0,0);
    static Stats StatBox = new Stats(0,0);
    static Amongusdead BuddyDead = new Amongusdead(0,0);
    static BlueSquare Enemy = new BlueSquare(0,0);
    static RedSquare Enemy1 = new RedSquare(0,0);
    static GreenSquare Enemy2 = new GreenSquare(0,0);
    static boolean decision = false;
    
    //Custom Background Color Pallets
    static Color GrassGreen = new Color(141, 194, 89);
    static Color Salmon = new Color(199, 115, 91);
    static Color DarkOrange = new Color(191, 113, 44);
    
    public static void main(String[] args) 
    { // start main    
          showGameBoard(gb);
          gb.setBackground(GrassGreen);
    }   //end main
    public void draw(Graphics g)
    {// start draw
        
        Main.show(g);
        rock1.show(g);
        //BattleStage.show(g);
        //Buddy.show(g);
        //StatBox.show(g);
        
        int diffX = Math.abs(Main.getX() - rock1.getX());
        int diffY = Math.abs(Main.getY() - rock1.getY());
        
        //Check for the users position
        //System.out.println("User is at x=" + Main.getX() + " y=" + Main.getY());
        
        if ((diffX >= 81)&&(diffX <= 99)&&(diffY >= 93)&&(diffY <= 102)){//start if the user runs into the rock
            
            gb.setBackground(Color.BLACK);
            Main.setX(-66);
            Main.setY(-96);
        
        //Ask the user what they would like to do
        String s1;
        Boolean decision = false;
        
        s1 = JOptionPane.showInputDialog("Would you like to fight? Enter Y or N ");
        
        if(s1.equalsIgnoreCase("y")){//start if           
            JOptionPane.showMessageDialog(null,"Ah...good man");
            decision = true;           
        }//end if
        else if(s1.equalsIgnoreCase("n")){//start else if            
            JOptionPane.showMessageDialog(null,"Be gone on your merry way then...");
            decision = false;           
        }//end else if
        else{//start else           
            JOptionPane.showMessageDialog(null,"Try again");
            decision = false;
        }//end else
        
        //Create an if statment to change background to battle
        if (decision){//starts if the user says yes to battle
            Graphics2D g2d = (Graphics2D) g;
            Color color1 = Color.GRAY;
            Color color2 = Color.ORANGE;
            GradientPaint gp = new GradientPaint(0, 100, color1,0, 300, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, 500, 500);
            
            BattleStage.show(g);
            Buddy.show(g);
            //BuddyDead.show(g);
            StatBox.show(g);
            
            String Randallmon [] = new String [3];
            Randallmon[0] = "Blue Square" ;
            Randallmon[1] = "Red Square";
            Randallmon[2] = "Green Square";     
        
            Random random = new Random();
            int randomIndex = random.nextInt(Randallmon.length);
            String randomRandall = Randallmon[randomIndex];
            int BShealth = 100;
            int Buddyhealth = 100;
            
            if(randomRandall == "Blue Square"){//start if opponent is blue square
                
                //int BShealth = 100;
                //int Buddyhealth = 100;                
                
                Enemy.show(g);
                
                for(BShealth=100; BShealth>0 ;BShealth++){
                    if((BShealth>0)&&(Buddyhealth>0)){
                        s1 = JOptionPane.showInputDialog("Type the letter of the move you would like to do. \n(a)Sabotage \n(b)Vent Ambush \n(c)Ejection \n(d)Shapeshift");
                        if(s1.equalsIgnoreCase("a")){//start if
                            
                            Random Bdamage = new Random();
                            int Damage = Bdamage.nextInt(100)+1; 
                            System.out.println("You used sabotage attack and did " + Damage + " damage!");                           
                            BShealth = BShealth - Damage;
                            System.out.println("Blue Square has " + BShealth + " health now");
                        }
                        else if(s1.equalsIgnoreCase("b")){
                             
                            Random Bdamage = new Random();
                            int Damage = Bdamage.nextInt(100)+1; 
                            System.out.println("You used Vent Ambush attack and did " + Damage + " damage!");
                            BShealth = BShealth - Damage;
                            System.out.println("Blue Square has " + BShealth + " health now");
                        }
                        else if(s1.equalsIgnoreCase("c")){
                             
                            Random Bdamage = new Random();
                            int Damage = Bdamage.nextInt(100)+1; 
                            System.out.println("You used Ejection attack and did " + Damage + " damage!");
                            BShealth = BShealth - Damage;
                            System.out.println("Blue Square has " + BShealth + " health now");
                        }
                        else if(s1.equalsIgnoreCase("d")){
                             
                            Random Bdamage = new Random();
                            int Damage = Bdamage.nextInt(100)+1; 
                            System.out.println("You used Shapeshifter attack and did " + Damage + " damage!");
                            BShealth = BShealth - Damage;
                            System.out.println("Blue Square has " + BShealth + " health now");
                        }
                        
                        //Create an array of BlueSquares attacks
                        String BSattack [] = new String [4];
                        BSattack[0] = "poop";
                        BSattack[1] = "poopy";
                        BSattack[2] = "poopi";       
                        BSattack[3] = "poo";   
                        
                        Random Eattack = new Random();
                        int EattackIndex = random.nextInt(BSattack.length);
                        String randomBSattack = BSattack[randomIndex];
                        System.out.println("Blue Square used " + randomBSattack + " attack");
                
                        //Create a random number generator for damage
                        Random Edamage = new Random();
                        int Damage = Edamage.nextInt(100)+1;
                        Buddyhealth = Buddyhealth - Damage;                       
                        System.out.println("Blue Square did " + Damage + " damage! You now have " + Buddyhealth + " health");
                        
                        if(BShealth<=0){
                            JOptionPane.showMessageDialog(null,"Congrats! You defeated Blue Square");
                        }
                        if(Buddyhealth<=0){
                            BuddyDead.show(g);
                            JOptionPane.showMessageDialog(null,"You fainted...better luck next time champ");
                        }
                    }
                }
                
                
                
                
                
                
                
                
                
                
                
                
            }//ends if the opponent is blue square
            else if(randomRandall == "Red Square"){//starts if the opponent is red square
                Enemy1.show(g);
                
                //Create an array of RedSquares attacks
                String RSattack [] = new String [4];
                RSattack[0] = "Sniff";
                RSattack[1] = "Smell";
                RSattack[2] = "Stab";       
                RSattack[3] = "Poop";      
                        
                Random E1attack = new Random();
                int E1attackIndex = random.nextInt(RSattack.length);
                String randomRSattack = RSattack[randomIndex];
                System.out.println("Red Square used " + randomRSattack + " attack");
                               
                //Create a random number generator for damage
                Random Edamage = new Random();
                int Damage = Edamage.nextInt(100)+1;
                System.out.println("Red Square did " + Damage + " damage!");               
                
            }//ends if the opponent is red square
            else if(randomRandall == "Green Square"){//starts if the opponent is green square
                Enemy2.show(g);
                
                //Create an array of GreenSquares attacks
                String GSattack [] = new String [4];
                GSattack[0] = "Punch";
                GSattack[1] = "Kick";
                GSattack[2] = "Headbutt";       
                GSattack[3] = "Smack";       
                        
                Random E2attack = new Random();
                int E2attackIndex = random.nextInt(GSattack.length);
                String randomGSattack = GSattack[randomIndex];
                System.out.println("Green Square used " + randomGSattack + " attack");
                
                //Create a random number generator for damage
                Random Edamage = new Random();
                int Damage = Edamage.nextInt(100)+1;
                System.out.println("Green Square did " + Damage + " damage!");
            }//ends if the opponent is green square
    
            
        }//ends if the user goes into battle
        else{//If the user decides ti run instead of fight
        gb.setBackground(GrassGreen);  
        }
        
              
    }//end if the user runs into the rock

    gb.setBackground(GrassGreen); 
        

        
        
        
        }//end draw
            
     
    //Create move methods
    public void moveRight(User Main)
    {
        int currentX = Main.getX();
        currentX = currentX + 3;
        Main.setX(currentX);
    }
    
    public void moveLeft(User Main)
    {
        int currentX = Main.getX();
        currentX = currentX - 3;
        Main.setX(currentX);
    }
    
    public void moveUp(User Main)
    {
        int currentY = Main.getY();
        currentY = currentY - 3;
        Main.setY(currentY);
    }
    
    public void moveDown(User Main)
    {
        int currentY = Main.getY();
        currentY = currentY + 3;
        Main.setY(currentY);
    }
   
   //Create a keyStruck method to bind the movement directions to a key
   public void keyStruck(char key){
        switch (key)
        {
            case 'D': case 'd':
                moveRight(Main);
                break;
                
            case 'A': case 'a':
                moveLeft(Main);
                break;
                
            case 'W': case 'w':
                moveUp(Main);
                break;
                
            case 'S': case 's':
                moveDown(Main);
                break;
        }    
    } 
   
   //Create a keyStruck method to bind the movement directions to a key
   /*public void keyStruckArrow(char key){
        switch (key)
        {
            case 'L': case 'l':
                moveRight(Arrow);
                break;
                
            case 'J': case 'j':
                moveLeft(Arrow);
                break;
                
            case 'I': case 'i':
                moveUp(Arrow);
                break;
                
            case 'K': case 'k':
                moveDown(Arrow);
                break;
        }    
    }  
   */
    
   
   
}// end class
 
