/*
Among us object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class Amongus {
    
    private int x=0;
    private int y=0;
    private boolean visible = true;
    
    static Color SussyYellow = new Color(232, 252, 3);
    static Color Helmet = new Color(181, 243, 247);

public Amongus (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
    //Draw Amongus
    g.setColor(Color.BLACK);
    g.drawRect(x+50, y+410, 120, 90);
    g.drawArc(x+65, y+324, 160, 170, 0, 180);
    g.drawRect(x+225, y+410, 1, 100);
    g.drawArc(x+215, y+385, 15, 35, 110, -180);
    
    g.setColor(SussyYellow);
    g.fillRect(x+51, y+411, 119, 89);
    g.fillArc(x+66, y+325, 158, 169, 0, 180);
    g.fillRect(x+171, y+410, 53, 100);
    
    g.setColor(Helmet);
    g.fillArc(x+219, y+385, 11, 34, 110, -180);
   
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method
    
public boolean getVisible(){
        return visible;
    }
    public void setVisible(boolean newVisible) {
        visible = newVisible;
    }    
}
