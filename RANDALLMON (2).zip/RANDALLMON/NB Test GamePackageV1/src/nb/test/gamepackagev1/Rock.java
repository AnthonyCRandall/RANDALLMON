/*
Rock Object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class Rock {// Starts class

    private int x=0;
    private int y=0;
    
    private boolean visible = true;
    
    static Color UserBrown = new Color(163, 100, 36);

public Rock (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
    //Skin
    g.setColor(UserBrown);
    g.fillRect(x+150, y+150, 30, 30);
}

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method

  
}//end class
