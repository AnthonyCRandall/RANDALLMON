/*
Stats Object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class Stats {
    
    private int x=0;
    private int y=0;

public Stats (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method
    
    //Stat box
    g.setColor(Color.BLACK);
    g.drawRect(x+285, y+360, 185, 75);
    
    g.setColor(Color.WHITE);
    g.fillRect(x+286, y+362, 184, 73);
    
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method
    
}
