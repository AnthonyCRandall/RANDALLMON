/*
GreenSquare Object
 */
package nb.test.gamepackagev1;
import java.awt.*;

public class GreenSquare {
    
    private int x=0;
    private int y=0;
    
public GreenSquare (int x, int y){// start method
    
    this.x=x;
    this.y=y;
    
}// end method

public void show(Graphics g){// start method    
    
    g.setColor(Color.GREEN); 
    g.fillRect(x+350, y+225, 30, 30);
    
}// Ends method

public int getX(){//start getX method
    return x;
}//end getX method

public void setX(int newX){//start setX method
    x=newX;
}//end setX method

public int getY(){//start getX method
    return y;
}//end getX method

public void setY(int newY){//start setX method
    y=newY;
}//end setX method    
    
}
